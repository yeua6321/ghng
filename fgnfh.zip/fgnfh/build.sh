#!/usr/bin/env sh

docker build -t vevc/fml .
